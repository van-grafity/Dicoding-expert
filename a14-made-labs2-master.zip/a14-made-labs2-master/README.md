## a14-made-labs2
Repository ini berisi kode hasil dari codelab yang ada di **Modul 2 kelas Menjadi Android Developer Expert di Dicoding**.
Di dalamnya terdapat materi:
* View dan ViewGroup
* Style dan Theme
* CustomView
* RecyclerView
* Navigation
* Localization
* Espresso (Instrumental Testing)

Jadilah expert di dunia pemrograman Android. Materi disusun oleh **Dicoding sebagai Google Authorized Training Partner**.
Ikuti [kelas Menjadi Android Developer Expert](https://www.dicoding.com/academies/14/) di Dicoding Indoensia
